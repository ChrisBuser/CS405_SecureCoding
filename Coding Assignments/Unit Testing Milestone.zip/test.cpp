// Uncomment the next line to use precompiled headers
#include "pch.h"
// uncomment the next line if you do not use precompiled headers
// #include "gtest/gtest.h"
//
// the global test environment setup and tear down
// you should not need to change anything here
class Environment : public ::testing::Environment
{
public:
    ~Environment() override {}

    // Override this to define how to set up the environment.
    void SetUp() override
    {
        //  initialize random seed
        srand(time(nullptr));
    }

    // Override this to define how to tear down the environment.
    void TearDown() override {}
};

// create our test class to house shared data between tests
// you should not need to change anything here
class CollectionTest : public ::testing::Test
{
protected:
    // create a smart point to hold our collection
    std::unique_ptr<std::vector<int>> collection;

    void SetUp() override
    { // create a new collection to be used in the test
        collection.reset(new std::vector<int>);
    }

    void TearDown() override
    { //  erase all elements in the collection, if any remain
        collection->clear();
        // free the pointer
        collection.reset(nullptr);
    }

    // helper function to add random values from 0 to 99 count times to the collection
    void add_entries(int count)
    {
        assert(count > 0);
        for (auto i = 0; i < count; ++i)
            collection->push_back(rand() % 100);
    }
};

// When should you use the EXPECT_xxx or ASSERT_xxx macros?
// Use ASSERT when failure should terminate processing, such as the reason for the test case.
// Use EXPECT when failure should notify, but processing should continue

// Test that a collection is empty when created.
// Prior to calling this (and all other TEST_F defined methods),
//  CollectionTest::StartUp is called.
// Following this method (and all other TEST_F defined methods),
//  CollectionTest::TearDown is called
TEST_F(CollectionTest, CollectionSmartPointerIsNotNull)
{
    // is the collection created
    ASSERT_TRUE(collection);

    // if empty, the size must be 0
    ASSERT_NE(collection.get(), nullptr);
}

// Test that a collection is empty when created.
TEST_F(CollectionTest, IsEmptyOnCreate)
{
    // is the collection empty?
    ASSERT_TRUE(collection->empty());

    // if empty, the size must be 0
    ASSERT_EQ(collection->size(), 0);
}

/* Comment this test out to prevent the test from running
 * Uncomment this test to see a failure in the test explorer */
//TEST_F(CollectionTest, AlwaysFail)
//{
//    FAIL();
//}

// Create a test to verify adding a single value to an empty collection
TEST_F(CollectionTest, CanAddToEmptyVector)
{
    // is the collection empty?
    // if empty, the size must be 0
    ASSERT_TRUE(collection->empty());

    add_entries(1);

    // is the collection still empty?
    // if not empty, what must the size be?
    ASSERT_EQ(collection->size(), 1);
}

// Create a test to verify adding five values to collection
TEST_F(CollectionTest, CanAddFiveValuesToVector)
{
    // is the collection empty?
    // if empty, the size must be 0
    ASSERT_TRUE(collection->empty());

    add_entries(5);

    // is the collection still empty?
    // if not empty, what must the size be?
    ASSERT_EQ(collection->size(), 5);
}

// Create a test to verify that max size is greater than or equal to size for 0, 1, 5, 10 entries
TEST_F(CollectionTest, MaxSizeGreaterThanOrEqualToSize)
{
    std::vector<int> counts = { 0, 1, 5, 10 };

    // test all 4 counts within one loop
    for (auto count : counts) {
        // free memory and create new vector each 
        collection.reset(new std::vector<int>);
        // do not call add_entries with 0. 
        // add_entries asserts count > 0
        if (count > 0) {
            add_entries(count);
        }

        // use expect to allow other tests in loop to continue
        // max_size should be greater than size for any count passed to add_entries
        EXPECT_GE(collection->max_size(), collection->size());
    }
}

// Create a test to verify that capacity is greater than or equal to size for 0, 1, 5, 10 entries
TEST_F(CollectionTest, CapacityGreaterThanOrEqualToSize)
{
    std::vector<int> counts = { 0, 1, 5, 10 };

    // test all 4 counts within one loop
    for (auto count : counts) {
        // free memory and create new vector each iteration
        collection.reset(new std::vector<int>);
        // do not call add_entries with 0. 
        // add_entries asserts count > 0
        if (count > 0) {
            add_entries(count);
        }

        // use expect to allow other tests in loop to continue
        // max_size should be greater than size for any count passed to add_entries
        EXPECT_GE(collection->capacity(), collection->size());
    }
}

// Create a test to verify resizing increases the collection
TEST_F(CollectionTest, ResizeIncreasesCollection)
{
    // begin with 1 entry and capture size
    add_entries(1);
    size_t size_before = collection->size();

    // increase size by 1 and capture final size
    collection->resize(size_before + 1);
    size_t size_after = collection->size();

    // after resize with larger value, size should be greater than before
    ASSERT_GT(size_after, size_before);
}

// Create a test to verify resizing decreases the collection
TEST_F(CollectionTest, ResizeDecreasesCollection)
{
    // begin with 2 entry and capture size
    add_entries(2);
    size_t size_before = collection->size();

    // decrease size by 1 and capture final size
    collection->resize(size_before - 1);
    size_t size_after = collection->size();

    // after resize with larger value, size should be less than before
    ASSERT_LT(size_after, size_before);
}

// Create a test to verify resizing decreases the collection to zero
TEST_F(CollectionTest, ResizeDecreasesCollectionToZero)
{
    add_entries(1);

    collection->resize(0);

    // after resize(0), collection should be empty
    ASSERT_TRUE(collection->empty());
}

// Create a test to verify clear erases the collection
TEST_F(CollectionTest, ClearErasesCollection)
{
    add_entries(5);

    collection->clear();

    // clear() should result in an empty collection
    ASSERT_TRUE(collection->empty());
}

// Create a test to verify erase(begin,end) erases the collection
TEST_F(CollectionTest, EraseBeginToEndErasesTheCollection)
{
    add_entries(10);

    collection->erase(collection->begin(), collection->end());

    // erase() from first element up to and including last element
    // should result in an entirely empty collection
    ASSERT_TRUE(collection->empty());
}

// Create a test to verify reserve increases the capacity but not the size of the collection
TEST_F(CollectionTest, ReserveIncreasesCapacityNotSize)
{
    add_entries(5);

    // capture capacity and size before reserve
    size_t capacity_before = collection->capacity();
    size_t size_before = collection->size();

    // reserve more memory for the collection
    collection->reserve(10);
    // capture capacity and size after reserve
    size_t capacity_after = collection->capacity();
    size_t size_after = collection->size();

    // what will happen to capacity when reserving more space? should increase
    // what about size? should remain the same
    // use EXPECT to allow multiple test cases in the event of a failure
    EXPECT_GT(capacity_after, capacity_before);
    EXPECT_EQ(size_after, size_before);
}

// Create a test to verify the std::out_of_range exception is thrown when calling at() with an index out of bounds
// NOTE: This is a negative test
TEST_F(CollectionTest, ThrowOutOfRangeExceptionWhenIndexOutOfBounds)
{
    add_entries(5);

    // call at() for the immediate index out of bounds
    ASSERT_THROW(collection->at(collection->size()), std::out_of_range);
}

// New positive test
// Create a test to verify multiple add_entries() calls result in correct size
TEST_F(CollectionTest, MultipleAddEntriesCallsIncreasesToAccurateSize)
{
    add_entries(5);
    add_entries(10);

    // if add_entries is called multiple times, what should final size be?
    ASSERT_EQ(collection->size(), 15);
}

// New negative test
// Create a test to verify accessing an empty collection throws std::out_range_exception
TEST_F(CollectionTest, ThrowOutOfRangeExceptionWhenEmptyAndIndexZero)
{
    // even index 0 out of bounds when there are no elements in collection
    ASSERT_THROW(collection->at(0), std::out_of_range);
}



