// BufferOverflow.cpp : This file contains the 'main' function. Program execution begins and ends there.
//

#include <iomanip>
#include <iostream>

int main()
{
  std::cout << "Buffer Overflow Example" << std::endl;

  // TODO: The user can type more than 20 characters and overflow the buffer, resulting in account_number being replaced -
  //  even though it is a constant and the compiler buffer overflow checks are on.
  //  You need to modify this method to prevent buffer overflow without changing the account_number
  //  variable, and its position in the declaration. It must always be directly before the variable used for input.
  //  You must notify the user if they entered too much data.

  const std::string account_number = "CharlieBrown42";
  char user_input[20];
  std::cout << "Enter a value: ";
  //std::cin >> user_input;	// existing line. comment out. accept input below


  // NEW LINES BELOW

  // declare boolean variable to track input validation
  bool valid_input = true;

  // prevents user_input from accepting more than 20 characters (19 + null terminator)
  std::cin.getline(user_input, sizeof(user_input));

  // getline() sets the failbit if input greater than length of sizeof(user_input)
  // clear the failbit to allow future input
  // getline() gives false positive when reaching eof but before sizeof(user_input), ignore this case 
  if (std::cin.fail() && !std::cin.eof()) {

	  std::cout << "Invalid input. Input too long." << std::endl;
	  std::cin.clear(); // clear error on stream caused by overflow
	  std::cin.ignore(std::numeric_limits<std::streamsize>::max(), '\n'); // discard the rest of the input until the newline character

	  valid_input = false;	// do not display input
  }


  // only display input if valid length
  if (valid_input) {
	  std::cout << "You entered: " << user_input << std::endl;	// existing line
  }

  // NEW LINES ABOVE

  std::cout << "Account Number = " << account_number << std::endl;
}

// Run program: Ctrl + F5 or Debug > Start Without Debugging menu
// Debug program: F5 or Debug > Start Debugging menu
