// Exceptions.cpp : This file contains the 'main' function. Program execution begins and ends there.
//

#include <iostream>

// Define class for custom exception
class CustomException : public std::exception {
private: 
    std::string message;

public:
    explicit CustomException() {
        message = "Custom error occurred.";
    }
    const char* what() const noexcept override {
        return message.c_str();
    }
};


bool do_even_more_custom_application_logic()
{
	// Throw an exception derived from std::exception
	throw std::runtime_error("RUNTIME ERROR");

	std::cout << "Running Even More Custom Application Logic." << std::endl;

	return true;
}
void do_custom_application_logic()
{
	std::cout << "Running Custom Application Logic." << std::endl;

	// wrap call in try block
	// worried about exception occurring
	try {
		if (do_even_more_custom_application_logic())
		{
			std::cout << "Even More Custom Application Logic Succeeded." << std::endl;
		}
	}
	catch (const std::exception& e) {
		std::cout << "Caught standard exception. " << e.what() << std::endl;	// print error to console
	}

	// Throw a custom exception derived from std::exception
	throw CustomException();

	std::cout << "Leaving Custom Application Logic." << std::endl;

}

float divide(float num, float den)
{
	// dividing by zero is an undefined behavior
	// throw exception to protect program
	if (den == 0) {
		throw std::invalid_argument("Cannot divide by 0");
	}

	return (num / den);
}

void do_division() noexcept
{
	// wrap function logic in try block
	// only catch exception thrown in divide()
	try {
		float numerator = 10.0f;
		float denominator = 0;

		auto result = divide(numerator, denominator);
		std::cout << "divide(" << numerator << ", " << denominator << ") = " << result << std::endl;
	}
	catch (const std::invalid_argument& e) {
		std::cout << "Caught invalid argument exception. " << e.what() << std::endl;
	}
}

int main()
{
	// wrapping contents of main in try block
	try {
		std::cout << "Exceptions Tests!" << std::endl;

		do_division();
		do_custom_application_logic();
	}
	catch (const CustomException& e) {
		std::cout << "Caught custom exception. " << e.what() << std::endl;
	}
	catch (const std::exception& e) {
		std::cout << "Caught standard exception. " << e.what() << std::endl;
	}
	catch (...) {
		std::cout << "Caught unexpected exception. " << std::endl;
	}
}

// Run program: Ctrl + F5 or Debug > Start Without Debugging menu
// Debug program: F5 or Debug > Start Debugging menu